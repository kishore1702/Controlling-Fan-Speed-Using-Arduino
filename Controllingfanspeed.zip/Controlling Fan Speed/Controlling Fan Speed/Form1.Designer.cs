﻿namespace Controlling_Fan_Speed
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.speed4 = new System.Windows.Forms.Button();
            this.speed3 = new System.Windows.Forms.Button();
            this.speed0 = new System.Windows.Forms.Button();
            this.speed1 = new System.Windows.Forms.Button();
            this.speed2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM3";
            // 
            // speed4
            // 
            this.speed4.Location = new System.Drawing.Point(95, 12);
            this.speed4.Name = "speed4";
            this.speed4.Size = new System.Drawing.Size(75, 23);
            this.speed4.TabIndex = 0;
            this.speed4.Text = "4";
            this.speed4.UseVisualStyleBackColor = true;
            this.speed4.Click += new System.EventHandler(this.speed5_Click);
            // 
            // speed3
            // 
            this.speed3.Location = new System.Drawing.Point(95, 61);
            this.speed3.Name = "speed3";
            this.speed3.Size = new System.Drawing.Size(75, 23);
            this.speed3.TabIndex = 1;
            this.speed3.Text = "3";
            this.speed3.UseVisualStyleBackColor = true;
            this.speed3.Click += new System.EventHandler(this.speed4_Click);
            // 
            // speed0
            // 
            this.speed0.Location = new System.Drawing.Point(95, 207);
            this.speed0.Name = "speed0";
            this.speed0.Size = new System.Drawing.Size(75, 23);
            this.speed0.TabIndex = 2;
            this.speed0.Text = "0";
            this.speed0.UseVisualStyleBackColor = true;
            this.speed0.Click += new System.EventHandler(this.speed0_Click);
            // 
            // speed1
            // 
            this.speed1.Location = new System.Drawing.Point(95, 157);
            this.speed1.Name = "speed1";
            this.speed1.Size = new System.Drawing.Size(75, 23);
            this.speed1.TabIndex = 3;
            this.speed1.Text = "1";
            this.speed1.UseVisualStyleBackColor = true;
            this.speed1.Click += new System.EventHandler(this.speed1_Click);
            // 
            // speed2
            // 
            this.speed2.Location = new System.Drawing.Point(95, 112);
            this.speed2.Name = "speed2";
            this.speed2.Size = new System.Drawing.Size(75, 23);
            this.speed2.TabIndex = 4;
            this.speed2.Text = "2";
            this.speed2.UseVisualStyleBackColor = true;
            this.speed2.Click += new System.EventHandler(this.speed2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.speed2);
            this.Controls.Add(this.speed1);
            this.Controls.Add(this.speed0);
            this.Controls.Add(this.speed3);
            this.Controls.Add(this.speed4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button speed4;
        private System.Windows.Forms.Button speed3;
        private System.Windows.Forms.Button speed0;
        private System.Windows.Forms.Button speed1;
        private System.Windows.Forms.Button speed2;
    }
}

