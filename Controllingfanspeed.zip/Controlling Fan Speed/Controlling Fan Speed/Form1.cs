﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Controlling_Fan_Speed
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void speed5_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            serialPort1.Write("a");
            serialPort1.Close();
        }

        private void speed4_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            serialPort1.Write("b");
            serialPort1.Close();
        }

        private void speed2_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            serialPort1.Write("c");
            serialPort1.Close();
        }

        private void speed1_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            serialPort1.Write("d");
            serialPort1.Close();
        }
        private void speed0_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            serialPort1.Write("e");
            serialPort1.Close();
        }
    }
}
